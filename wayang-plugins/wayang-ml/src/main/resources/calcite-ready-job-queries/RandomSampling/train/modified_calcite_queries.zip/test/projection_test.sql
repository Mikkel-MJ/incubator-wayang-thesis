SELECT ct.id
FROM postgres.company_type AS ct;

SELECT * FROM postgres.movie_companies WHERE movie_companies.id <> 1;
